from one import one, test_one
from three import fibbonacci

print(one("Acting 101"))
test_one()

print(fibbonacci(9))
